// backend/routes/publicBooks.js
// Read-only endpoints used by the public site (/site and /site/books).

const express = require("express");
const router = express.Router();
const crypto = require("crypto");
const { resolveCoverUrl, resolveLocaleCover } = require("../utils/covers");
const {
  normalizeTitleLocale,
  titleTranslationsReady,
  titleTranslationJoin,
  titlePurchaseUrlReady,
  ttPurchaseUrlExpr,
} = require("../utils/titleLocale");

function getPool(req) {
  const pool = req.app.get("pgPool");
  if (!pool) throw new Error("pgPool missing on app");
  return pool;
}

const clampInt = (x, def, min, max) => {
  const n = Number.parseInt(x, 10);
  if (!Number.isFinite(n)) return def;
  return Math.max(min, Math.min(max, n));
};

function normStr(v) {
  if (v === undefined || v === null) return null;
  const s = String(v).trim();
  return s ? s : null;
}

function isUuid(v) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
    String(v || "")
  );
}

const normKey = (s) =>
  String(s || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");

async function resolveAuthorByKey(pool, key) {
  const k = normStr(key);
  if (!k) return null;

  if (isUuid(k)) {
    const { rows } = await pool.query(
      `
      SELECT id::text AS id, name_display, abbr AS abbreviation, published_titles
      FROM public.authors
      WHERE id = $1::uuid
      LIMIT 1
      `,
      [k]
    );
    return rows?.[0] || { id: k };
  }

  const kNorm = normKey(k);

  const { rows } = await pool.query(
    `
    SELECT id::text AS id, name_display, abbr AS abbreviation, published_titles
    FROM public.authors
    WHERE
      LOWER(abbr) = LOWER($1)
      OR regexp_replace(lower(abbr), '[^a-z0-9]+', '', 'g') = $2
      OR LOWER(name_display) = LOWER($1)
    ORDER BY
      CASE
        WHEN LOWER(name_display) = LOWER($1) THEN 0
        WHEN LOWER(abbr) = LOWER($1) THEN 1
        WHEN regexp_replace(lower(abbr), '[^a-z0-9]+', '', 'g') = $2 THEN 2
        ELSE 9
      END,
      name_display ASC
    LIMIT 1
    `,
    [k, kNorm]
  );

  return rows?.[0] || null;
}

function getClientIp(req) {
  const xf = String(req.headers["x-forwarded-for"] || "");
  if (xf) return xf.split(",")[0].trim();
  return req.socket?.remoteAddress || "";
}

function hashIp(ip) {
  const salt = String(process.env.IP_HASH_SALT || "zr");
  const raw = `${salt}:${String(ip || "")}`;
  return crypto.createHash("sha256").update(raw).digest("hex");
}

function countLinks(text) {
  const m = String(text || "").match(/https?:\/\/\S+/gi);
  return m ? m.length : 0;
}

// single sources of truth for public display
// authors: only name_display is public (name/full_name hold raw import data)
const AUTHOR_EXPR = "NULLIF(TRIM(a.name_display), '')";
const TITLE_EXPR =
  "COALESCE(NULLIF(b.title_display,''), NULLIF(b.title_keyword,''))";
// canonical publisher name only – legacy books.publisher may no longer exist
const PUBLISHER_EXPR = "p.name";

// purchase providers (optional) — compute best link from isbn + templates
function applyTemplate(tpl, { isbn13, isbn10, bookId }) {
  let url = String(tpl || "");
  url = url.replace(/\{isbn13\}/g, isbn13 || "");
  url = url.replace(/\{isbn10\}/g, isbn10 || "");
  url = url.replace(/\{isbn\}/g, isbn13 || isbn10 || "");
  url = url.replace(/\{book_id\}/g, bookId || "");
  return url;
}

async function buildPurchaseLinks(pool, { isbn13, isbn10, bookId }) {
  const isbnAny = (isbn13 || isbn10 || "").trim();
  if (!isbnAny) return { best: null, candidates: [] };

  const { rows } = await pool.query(
    `
    SELECT id, code, name, url_template, priority
    FROM public.purchase_providers
    WHERE is_active=true AND kind='buy'
    ORDER BY priority ASC, id ASC
    `
  );

  const candidates = (rows || [])
    .map((p) => {
      const url = applyTemplate(p.url_template, { isbn13, isbn10, bookId });
      return {
        provider_id: p.id,
        provider_code: p.code,
        provider_name: p.name,
        priority: p.priority,
        url,
      };
    })
    .filter((c) => c.url && !c.url.includes("{isbn") && !c.url.includes("{book_"));

  return { best: candidates[0] || null, candidates };
}


/**
 * GET /api/public/books/home-titles
 * Full history of titles shown on Home as Top Finished and Top Received.
 * Uses public.highlights, not current book flags, so it preserves history.
 *
 * IMPORTANT: keep this route above all /:id routes.
 */
router.get("/home-titles", async (req, res) => {
  try {
    const pool = getPool(req);
    const lang = normalizeTitleLocale(req.query.lang);
    const ttReady = await titleTranslationsReady(pool);

    const { rows } = await pool.query(`
      SELECT
        h.id,
        h.presented_as,
        h.presented_at,
        h.presented_till,

        b.id::text AS id,
        b.id::text AS book_id,

        COALESCE(NULLIF(tt.title, ''), ${TITLE_EXPR}) AS title,
        ${TITLE_EXPR} AS title_original,
        tt.title_kind,
        tt.edition_available,
        ${AUTHOR_EXPR} AS author,

        ('/uploads/covers/normalized/' || b.id::text || '.jpg') AS cover_url

      FROM (
        SELECT DISTINCT ON (presented_as, book_id)
          *
        FROM public.highlights
        WHERE presented_as IN ('finished', 'received')
        ORDER BY
          presented_as,
          book_id,
          presented_at DESC,
          id DESC
      ) h

      JOIN public.books b
        ON b.id = h.book_id

      LEFT JOIN public.authors a
        ON a.id = b.author_id

      ${titleTranslationJoin(ttReady, "$1")}

      ORDER BY
        h.presented_as,
        h.presented_at DESC,
        h.id DESC
    `, [lang]);

    // Cover of the edition in the UI language, if one was uploaded.
    const books = (rows || []).map((row) => {
      const lc = lang ? resolveLocaleCover(row.id, lang) : null;
      return lc ? { ...row, cover_url: lc.full, cover_home: lc.home } : row;
    });

    res.json({ books });
  } catch (err) {
    console.error("GET /api/public/books/home-titles error", err);
    res.status(500).json({ error: "internal_error" });
  }
});

/**
 * GET /api/public/books
 */
router.get("/", async (req, res) => {
  try {
    const pool = getPool(req);

    const bucket = String(req.query.bucket || "registered").toLowerCase();
    const limit = clampInt(req.query.limit, 50, 1, 2000);
    const offset = clampInt(req.query.offset, 0, 0, 1_000_000);
    const yearRaw = normStr(req.query.year);
    const year = yearRaw
      ? clampInt(yearRaw, new Date().getFullYear(), 1970, 2100)
      : null;

    const author = normStr(req.query.author);
    const title = normStr(req.query.title);
    const q = normStr(req.query.q);

    const where = [];
    const params = [];

    const fromSql = `
      FROM public.books b
      LEFT JOIN public.authors a ON a.id = b.author_id
      LEFT JOIN public.publishers p ON p.id = b.publisher_id
      LEFT JOIN LATERAL (
        SELECT barcode
        FROM public.book_barcodes bb
        WHERE bb.book_id = b.id
        LIMIT 1
      ) bb ON true
      LEFT JOIN LATERAL (
        SELECT barcode, assigned_at
        FROM public.barcode_assignments ba
        WHERE ba.book_id = b.id
          AND ba.freed_at IS NULL
        ORDER BY ba.assigned_at DESC
        LIMIT 1
      ) open_ba ON true
    `;

    let orderBy = "b.registered_at DESC NULLS LAST, b.id ASC";
    if (bucket === "top") {
      where.push("b.top_book = true");
      orderBy =
        "b.top_book_set_at DESC NULLS LAST, b.registered_at DESC NULLS LAST, b.id ASC";
      if (year) {
        params.push(`${year}-01-01`);
        params.push(`${year + 1}-01-01`);
        where.push(
          `b.top_book_set_at >= $${params.length - 1}::timestamptz AND b.top_book_set_at < $${params.length}::timestamptz`
        );
      }
    } else if (bucket === "finished") {
      where.push("b.reading_status = 'finished'");
      orderBy =
        "b.reading_status_updated_at DESC NULLS LAST, b.registered_at DESC NULLS LAST, b.id ASC";
      if (year) {
        params.push(`${year}-01-01`);
        params.push(`${year + 1}-01-01`);
        where.push(
          `b.reading_status_updated_at >= $${params.length - 1}::timestamptz AND b.reading_status_updated_at < $${params.length}::timestamptz`
        );
      }
    } else if (bucket === "abandoned") {
      where.push("b.reading_status = 'abandoned'");
      orderBy =
        "b.reading_status_updated_at DESC NULLS LAST, b.registered_at DESC NULLS LAST, b.id ASC";
      if (year) {
        params.push(`${year}-01-01`);
        params.push(`${year + 1}-01-01`);
        where.push(
          `b.reading_status_updated_at >= $${params.length - 1}::timestamptz AND b.reading_status_updated_at < $${params.length}::timestamptz`
        );
      }
    } else if (bucket === "all") {
      // public collection: everything owned or read — no wishlist
      where.push("b.reading_status IN ('in_stock', 'in_progress', 'finished', 'abandoned')");
    } else if (bucket === "available") {
      // available = on the shelf or currently being read (home page "In meiner Sammlung")
      where.push("b.reading_status IN ('in_stock', 'in_progress')");
      orderBy =
        "b.reading_status_updated_at DESC NULLS LAST, b.registered_at DESC NULLS LAST, b.id ASC";
    } else if (bucket === "stock" || bucket === "in_stock") {
      where.push("(open_ba.barcode IS NOT NULL OR b.reading_status = 'in_stock')");
      orderBy =
        "COALESCE(open_ba.assigned_at, b.reading_status_updated_at, b.registered_at) DESC NULLS LAST, b.id ASC";
    }

    if (author) {
      const resolved = await resolveAuthorByKey(pool, author);
      if (resolved?.id && isUuid(resolved.id)) {
        params.push(resolved.id);
        const p = `$${params.length}`;
        where.push(
          `(
            b.author_id = ${p}::uuid
            OR EXISTS (
              SELECT 1 FROM public.book_authors ba
              WHERE ba.book_id = b.id AND ba.author_id = ${p}::uuid
            )
          )`
        );
      } else {
        params.push(`%${author}%`);
        const p = `$${params.length}`;
        where.push(
          `(
            ${AUTHOR_EXPR} ILIKE ${p}
          )`
        );
      }
    }

    if (title) {
      params.push(`%${title}%`);
      where.push(`${TITLE_EXPR} ILIKE $${params.length}`);
    }
    if (q) {
      params.push(`%${q}%`);
      const p = `$${params.length}`;
      where.push(
        `(
          ${TITLE_EXPR} ILIKE ${p} OR
          ${AUTHOR_EXPR} ILIKE ${p} OR
          a.abbr ILIKE ${p} OR
          ${PUBLISHER_EXPR} ILIKE ${p} OR
          b.title_keyword ILIKE ${p} OR
          b.title_keyword2 ILIKE ${p} OR
          b.title_keyword3 ILIKE ${p} OR
          b.isbn10 ILIKE ${p} OR
          b.isbn13 ILIKE ${p} OR
          COALESCE(open_ba.barcode, bb.barcode) ILIKE ${p}
        )`
      );
    }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const { rows: countRows } = await pool.query(
      `SELECT COUNT(*)::int AS total ${fromSql} ${whereSql}`,
      params
    );
    const total = countRows?.[0]?.total ?? 0;

    const dataParams = [...params, limit, offset];
    const limP = `$${params.length + 1}`;
    const offP = `$${params.length + 2}`;

    const { rows } = await pool.query(
      `
      SELECT
        b.id::text AS id,
        a.id::text AS author_id,
        ${AUTHOR_EXPR} AS author_name_display,
        ${TITLE_EXPR}  AS book_title_display,
        b.registered_at,
        b.reading_status,
        b.reading_status_updated_at,
        b.top_book,
        b.top_book_set_at,
        b.purchase_url,
        b.purchase_source,
        a.published_titles,
        COALESCE(open_ba.barcode, bb.barcode) AS barcode,
        (open_ba.barcode IS NOT NULL OR b.reading_status = 'in_stock') AS is_in_stock,
        ('/uploads/covers/normalized/' || b.id::text || '.jpg') AS cover
      ${fromSql}
      ${whereSql}
      ORDER BY ${orderBy}
      LIMIT ${limP}
      OFFSET ${offP}
      `,
      dataParams
    );

    const items = (rows || []).map((r) => ({
      id: r.id,
      author_id: r.author_id || null,
      authorId: r.author_id || null,

      authorNameDisplay: r.author_name_display || "",
      bookTitleDisplay: r.book_title_display || "",

      author: r.author_name_display || "",
      title: r.book_title_display || "",

      registered_at: r.registered_at,
      reading_status: r.reading_status,
      reading_status_updated_at: r.reading_status_updated_at,
      top_book: r.top_book,
      top_book_set_at: r.top_book_set_at,

      purchase_url: r.purchase_url || null,
      purchase_source: r.purchase_source || null,

      barcode: r.barcode || null,
      is_in_stock: !!r.is_in_stock,
      isInStock: !!r.is_in_stock,

      published_titles: r.published_titles ?? null,
      publishedTitles: r.published_titles ?? null,

      // filesystem check: finds new (normalized/) and old (covers/) covers
      cover: resolveCoverUrl(r.id) || null,
    }));

    const wantsMeta =
      String(req.query.meta || "").trim() === "1" || offset > 0;
    return wantsMeta
      ? res.json({ items, total, limit, offset })
      : res.json(items);
  } catch (err) {
    console.error("GET /api/public/books error", err);
    return res.status(500).json({ error: "internal_error" });
  }
});

/**
 * GET /api/public/books/stats?year=2026
 */
router.get("/stats", async (req, res) => {
  try {
    const pool = getPool(req);
    const year = clampInt(req.query.year, new Date().getFullYear(), 1970, 2100);

    const start = `${year}-01-01`;
    const end = `${year + 1}-01-01`;

    const { rows } = await pool.query(
      `
      WITH last_free AS (
        SELECT DISTINCT ON (ba.book_id)
          ba.book_id,
          ba.freed_at
        FROM public.barcode_assignments ba
        WHERE ba.freed_at IS NOT NULL
        ORDER BY ba.book_id, ba.freed_at DESC
      )
      SELECT
        (
  SELECT COUNT(*)::int
  FROM public.books b0
  WHERE (
    b0.reading_status = 'in_stock'
    OR EXISTS (
      SELECT 1
      FROM public.barcode_assignments ba0
      WHERE ba0.book_id = b0.id
        AND ba0.freed_at IS NULL
    )
  )
) AS inventory_total,
        (
          SELECT COUNT(*)::int
          FROM last_free lf
          JOIN public.books b2 ON b2.id = lf.book_id
          WHERE b2.reading_status = 'finished'
            AND lf.freed_at >= $1::timestamptz
            AND lf.freed_at <  $2::timestamptz
        ) AS finished,

        count(*) FILTER (
          WHERE b.reading_status = 'abandoned'
            AND b.reading_status_updated_at >= $1::timestamptz
            AND b.reading_status_updated_at <  $2::timestamptz
        )::int AS abandoned,

        count(*) FILTER (
          WHERE b.top_book = true
            AND b.top_book_set_at >= $1::timestamptz
            AND b.top_book_set_at <  $2::timestamptz
        )::int AS top
      FROM public.books b
      `,
      [start, end]
    );

    const out =
      rows[0] || { inventory_total: 0, finished: 0, abandoned: 0, top: 0 };

    // Legacy aliases for older frontends
    out.in_stock = out.inventory_total;
    out.instock = out.inventory_total;
    out.inStock = out.inventory_total;

    return res.json(out);
  } catch (err) {
    console.error("GET /api/public/books/stats error", err);
    return res.status(500).json({ error: "internal_error" });
  }
});

/**
 * GET /api/public/books/reading-diary?weeks=12
 * Lesetagebuch: Wochenzahlen (Mo–So, Europe/Berlin), neueste Woche zuerst.
 *   finished:   diese Woche beendet       (reading_status = finished,  reading_status_updated_at)
 *   abandoned:  diese Woche abgebrochen   (reading_status = abandoned, reading_status_updated_at)
 *   enriched:   diese Woche Daten ergänzt (enriched_at)
 *   uploaded:   diese Woche neu erhalten / hochgeladen (added_at)
 *   registered: diese Woche registriert   (registered_at)
 * Gleiche Definitionen wie GET /api/admin/activity/today, nur pro Woche.
 * Jede Zahl wird einzeln abgefragt: fehlt z. B. enriched_at, kommt dort null.
 */
const RD_TZ = "Europe/Berlin";
const RD_METRICS = [
  ["finished", "reading_status_updated_at", "AND b.reading_status::text = 'finished'"],
  ["abandoned", "reading_status_updated_at", "AND b.reading_status::text = 'abandoned'"],
  ["enriched", "enriched_at", ""],
  ["uploaded", "added_at", ""],
  ["registered", "registered_at", ""],
];

router.get("/reading-diary", async (req, res) => {
  try {
    const pool = getPool(req);
    const weeks = clampInt(req.query.weeks, 12, 1, 104);

    // Liste der Wochen (Montag als Datum), aktuelle Woche zuletzt
    const wk = await pool.query(
      `
      WITH cur AS (SELECT date_trunc('week', now() AT TIME ZONE '${RD_TZ}')::date AS d)
      SELECT to_char(gs::date, 'YYYY-MM-DD') AS week_start,
             to_char(gs::date + 6, 'YYYY-MM-DD') AS week_end,
             extract(isoyear FROM gs)::int AS iso_year,
             extract(week FROM gs)::int AS iso_week
      FROM cur, generate_series(cur.d - ($1::int - 1) * 7, cur.d, interval '7 days') AS gs
      ORDER BY gs DESC
      `,
      [weeks]
    );
    const list = wk.rows;
    const since = list[list.length - 1]?.week_start;

    const one = async ([key, col, extra]) => {
      try {
        const { rows } = await pool.query(
          `
          SELECT to_char(date_trunc('week', b.${col} AT TIME ZONE '${RD_TZ}')::date, 'YYYY-MM-DD') AS ws,
                 count(*)::int AS n
          FROM public.books b
          WHERE b.${col} >= ($1::date::timestamp AT TIME ZONE '${RD_TZ}') ${extra}
          GROUP BY 1
          `,
          [since]
        );
        return [key, Object.fromEntries(rows.map((r) => [r.ws, r.n]))];
      } catch (e) {
        console.error(`reading-diary ${key}:`, e?.message || e);
        return [key, null];
      }
    };
    const byMetric = Object.fromEntries(await Promise.all(RD_METRICS.map(one)));
    if (Object.values(byMetric).every((v) => v === null)) {
      return res.status(500).json({ error: "reading_diary_failed" });
    }

    const items = list.map((w) => {
      const out = { ...w };
      for (const [key] of RD_METRICS) {
        out[key] = byMetric[key] === null ? null : byMetric[key][w.week_start] || 0;
      }
      return out;
    });

    res.set("Cache-Control", "public, max-age=60");
    return res.json({ timezone: RD_TZ, weeks: items });
  } catch (err) {
    console.error("GET /api/public/books/reading-diary error", err);
    return res.status(500).json({ error: "internal_error" });
  }
});

/**
 * GET /api/public/books/author-suggest?q=kin&limit=6
 * Autocomplete for the public collection: authors whose name matches,
 * with the number of public books (owned or read, no wishlist).
 */
router.get("/author-suggest", async (req, res) => {
  try {
    const pool = getPool(req);
    const q = normStr(req.query.q);
    const limit = clampInt(req.query.limit, 6, 1, 20);
    if (!q || q.length < 2) return res.json([]);

    const { rows } = await pool.query(
      `
      SELECT
        a.id::text AS id,
        ${AUTHOR_EXPR} AS author,
        COUNT(b.id)::int AS count,
        COUNT(b.id) FILTER (WHERE b.reading_status IN ('in_stock', 'in_progress'))::int AS available
      FROM public.authors a
      JOIN public.books b ON b.author_id = a.id
      WHERE b.reading_status IN ('in_stock', 'in_progress', 'finished', 'abandoned')
        AND ${AUTHOR_EXPR} ILIKE $1
      GROUP BY a.id, 2
      ORDER BY
        -- name or a later word (e.g. surname) starts with the term
        (${AUTHOR_EXPR} ILIKE $2 OR ${AUTHOR_EXPR} ILIKE '% ' || $2) DESC,
        count DESC,
        author ASC
      LIMIT $3
      `,
      [`%${q}%`, `${q}%`, limit]
    );

    return res.json(rows.filter((r) => r.author && r.author.trim()));
  } catch (err) {
    console.error("GET /api/public/books/author-suggest error", err);
    return res.status(500).json({ error: "internal_error" });
  }
});

/**
 * GET /api/public/books/author-counts
 */
router.get("/author-counts", async (req, res) => {
  try {
    const pool = getPool(req);

    const bucket = String(req.query.bucket || "finished").toLowerCase();
    const limit = clampInt(req.query.limit, 50, 1, 500);
    const author = normStr(req.query.author);

    const where = [];
    const params = [];

    if (bucket === "top") where.push("b.top_book = true");
    else if (bucket === "abandoned") where.push("b.reading_status = 'abandoned'");
    else if (bucket === "registered") {
      // no filter
    } else where.push("b.reading_status = 'finished'");

    if (author) {
      params.push(`%${author}%`);
      where.push(`${AUTHOR_EXPR} ILIKE $${params.length}`);
    }

    where.push(`${AUTHOR_EXPR} IS NOT NULL`);
    where.push(`BTRIM(${AUTHOR_EXPR}) <> ''`);

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const { rows } = await pool.query(
      `
      SELECT
        ${AUTHOR_EXPR} AS author,
        COUNT(*)::int AS count
      FROM public.books b
      LEFT JOIN public.authors a ON a.id = b.author_id
      ${whereSql}
      GROUP BY 1
      ORDER BY count DESC, author ASC
      LIMIT $${params.length + 1}
      `,
      [...params, limit]
    );

    return res.json(rows);
  } catch (err) {
    console.error("GET /api/public/books/author-counts error", err);
    return res.status(500).json({ error: "internal_error" });
  }
});

/**
 * GET /api/public/books/stock-authors?limit=80
 */
router.get("/stock-authors", async (req, res) => {
  try {
    const pool = getPool(req);
    const limit = clampInt(req.query.limit, 80, 1, 200);

    const { rows } = await pool.query(
      `
      SELECT
        ${AUTHOR_EXPR} AS author,
        COUNT(*)::int AS count
      FROM public.books b
      LEFT JOIN public.authors a ON a.id = b.author_id
      WHERE (
          b.reading_status = 'in_stock'
          OR EXISTS (
            SELECT 1
            FROM public.barcode_assignments ba
            WHERE ba.book_id = b.id
              AND ba.freed_at IS NULL
          )
        )
        AND ${AUTHOR_EXPR} IS NOT NULL
        AND BTRIM(${AUTHOR_EXPR}) <> ''
      GROUP BY 1
      ORDER BY count DESC, author ASC
      LIMIT $1
      `,
      [limit]
    );

    return res.json(rows);
  } catch (err) {
    console.error("GET /api/public/books/stock-authors error", err);
    return res.status(500).json({ error: "internal_error" });
  }
});

/**
 * GET /api/public/books/most-read-authors
 */
router.get("/most-read-authors", async (req, res) => {
  try {
    const pool = getPool(req);
    const limit = clampInt(req.query.limit, 50, 1, 500);

    const { rows } = await pool.query(
      `
      WITH author_books AS (
        SELECT
          a.id AS author_id,
          ${AUTHOR_EXPR} AS author,
          b.id AS book_id,
          b.reading_status
        FROM public.books b
        JOIN public.authors a ON a.id = b.author_id

        UNION

        SELECT
          a.id AS author_id,
          ${AUTHOR_EXPR} AS author,
          ba.book_id AS book_id,
          b.reading_status
        FROM public.book_authors ba
        JOIN public.authors a ON a.id = ba.author_id
        JOIN public.books b ON b.id = ba.book_id
      ),
      author_stats AS (
        SELECT
          author_id,
          author,
          COUNT(DISTINCT book_id) FILTER (WHERE reading_status = 'finished')::int AS books_read,
          COUNT(DISTINCT book_id)::int AS books_total
        FROM author_books
        WHERE author IS NOT NULL
          AND BTRIM(author) <> ''
        GROUP BY author_id, author
        HAVING COUNT(DISTINCT book_id) FILTER (WHERE reading_status = 'finished') > 0
      ),
      ranked_books AS (
        SELECT
          s.author_id,
          b.id::text AS book_id,
          ${TITLE_EXPR} AS title_display,
          b.purchase_url,
          ROW_NUMBER() OVER (
            PARTITION BY s.author_id
            ORDER BY
              CASE
                WHEN s.books_total > 10 THEN
                  CASE WHEN b.featured_rank BETWEEN 1 AND 3 THEN 0 ELSE 1 END
                ELSE
                  CASE
                    WHEN b.featured_rank = 1 THEN 0
                    WHEN b.featured_rank IS NULL THEN 1
                    ELSE 2
                  END
              END,
              b.featured_rank ASC NULLS LAST,
              b.top_book DESC,
              b.top_book_set_at DESC NULLS LAST,
              (b.reading_status = 'finished') DESC,
              b.reading_status_updated_at DESC NULLS LAST,
              b.registered_at DESC NULLS LAST,
              b.id ASC
          ) AS rn
        FROM author_stats s
        JOIN author_books ab ON ab.author_id = s.author_id
        JOIN public.books b ON b.id = ab.book_id
      )
      SELECT
        s.author,
        s.books_read,
        s.books_total,
        CASE
          WHEN s.books_total > 10 THEN
            COALESCE(
              ARRAY_AGG(r.title_display ORDER BY r.rn)
                FILTER (
                  WHERE r.rn <= 3
                    AND r.title_display IS NOT NULL
                    AND BTRIM(r.title_display) <> ''
                ),
              '{}'::text[]
            )
          ELSE
            COALESCE(
              ARRAY_AGG(r.title_display ORDER BY r.rn)
                FILTER (
                  WHERE r.rn <= 1
                    AND r.title_display IS NOT NULL
                    AND BTRIM(r.title_display) <> ''
                ),
              '{}'::text[]
            )
        END AS featured_titles,
        CASE
          WHEN s.books_total > 10 THEN
            COALESCE(ARRAY_AGG(r.book_id ORDER BY r.rn) FILTER (WHERE r.rn <= 3), '{}'::text[])
          ELSE
            COALESCE(ARRAY_AGG(r.book_id ORDER BY r.rn) FILTER (WHERE r.rn <= 1), '{}'::text[])
        END AS featured_book_ids,
        CASE
          WHEN s.books_total > 10 THEN
            COALESCE(ARRAY_AGG(r.purchase_url ORDER BY r.rn) FILTER (WHERE r.rn <= 3), '{}'::text[])
          ELSE
            COALESCE(ARRAY_AGG(r.purchase_url ORDER BY r.rn) FILTER (WHERE r.rn <= 1), '{}'::text[])
        END AS featured_purchase_urls
      FROM author_stats s
      LEFT JOIN ranked_books r ON r.author_id = s.author_id
      GROUP BY s.author, s.books_read, s.books_total
      ORDER BY s.books_read DESC, s.books_total DESC, s.author ASC
      LIMIT $1
      `,
      [limit]
    );

    return res.json(
      (rows || []).map((r) => {
        const titles = Array.isArray(r.featured_titles)
          ? r.featured_titles.filter((x) => x && String(x).trim())
          : [];
        const best = titles[0] || null;

        return {
          author: r.author,
          books_read: r.books_read,
          booksRead: r.books_read,

          books_in_stock: r.books_total,
          booksInStock: r.books_total,

          best_title: best,
          bestTitle: best,

          titles,
          featured_titles: titles,
          featuredTitles: titles,
          featured_book_ids: r.featured_book_ids || [],
          featuredBookIds: r.featured_book_ids || [],
          featured_purchase_urls: r.featured_purchase_urls || [],
          featuredPurchaseUrls: r.featured_purchase_urls || [],

          count: r.books_read,
        };
      })
    );
  } catch (err) {
    console.error("GET /api/public/books/most-read-authors error", err);
    return res.status(500).json({ error: "internal_error" });
  }
});

/**
 * GET /api/public/books/:id/comments
 * Public: only approved comments.
 */
router.get("/:id/comments", async (req, res) => {
  try {
    const pool = getPool(req);
    const bookId = String(req.params.id || "").trim();
    if (!isUuid(bookId)) return res.status(400).json({ error: "invalid_book_id" });

    const limit = clampInt(req.query.limit, 200, 1, 500);

    const { rows } = await pool.query(
      `
      SELECT
        id::text AS id,
        book_id::text AS book_id,
        parent_id::text AS parent_id,
        COALESCE(NULLIF(author_name,''), 'Guest') AS author_name,
        body,
        created_at
      FROM public.book_comments
      WHERE book_id = $1::uuid
        AND status = 'approved'
      ORDER BY created_at ASC
      LIMIT $2
      `,
      [bookId, limit]
    );

    return res.json({ items: rows || [] });
  } catch (err) {
    if (String(err?.message || "").toLowerCase().includes("book_comments")) {
      return res.json({ items: [] });
    }
    console.error("GET /api/public/books/:id/comments error", err);
    return res.status(500).json({ error: "internal_error" });
  }
});

/**
 * POST /api/public/books/:id/comments
 * Guest: creates a pending comment.
 */
router.post("/:id/comments", async (req, res) => {
  try {
    const pool = getPool(req);
    const bookId = String(req.params.id || "").trim();
    if (!isUuid(bookId)) return res.status(400).json({ error: "invalid_book_id" });

    const authorName = normStr(req.body?.authorName ?? req.body?.author_name) || "";
    const body = normStr(req.body?.body) || "";
    const parentId = normStr(req.body?.parentId ?? req.body?.parent_id);
    const website = normStr(req.body?.website);

    if (website) return res.json({ ok: true, status: "pending" });

    if (body.length < 3) return res.status(400).json({ error: "comment_too_short" });
    if (body.length > 2000) return res.status(400).json({ error: "comment_too_long" });
    if (authorName.length > 80) return res.status(400).json({ error: "name_too_long" });
    if (parentId && !isUuid(parentId)) {
      return res.status(400).json({ error: "invalid_parent_id" });
    }
    if (countLinks(body) > 2) return res.status(400).json({ error: "too_many_links" });

    const exists = await pool.query(
      `SELECT 1 FROM public.books WHERE id = $1::uuid LIMIT 1`,
      [bookId]
    );
    if (!exists.rows?.[0]) return res.status(404).json({ error: "book_not_found" });

    const ip = getClientIp(req);
    const ipHash = hashIp(ip);
    const ua = normStr(req.headers["user-agent"]) || null;

    try {
      const recent10 = await pool.query(
        `
        SELECT count(*)::int AS c
        FROM public.book_comments
        WHERE ip_hash = $1
          AND created_at > (now() - interval '10 minutes')
        `,
        [ipHash]
      );
      if ((recent10.rows?.[0]?.c ?? 0) >= 5) {
        return res.status(429).json({ error: "rate_limited" });
      }

      const recent30 = await pool.query(
        `
        SELECT count(*)::int AS c
        FROM public.book_comments
        WHERE ip_hash = $1
          AND created_at > (now() - interval '30 seconds')
        `,
        [ipHash]
      );
      if ((recent30.rows?.[0]?.c ?? 0) >= 1) {
        return res.status(429).json({ error: "rate_limited" });
      }
    } catch {
      // ignore
    }

    const id = crypto.randomUUID();

    await pool.query(
      `
      INSERT INTO public.book_comments
        (id, book_id, parent_id, author_name, body, status, ip_hash, user_agent)
      VALUES
        ($1::uuid, $2::uuid, $3::uuid, $4, $5, 'pending', $6, $7)
      `,
      [id, bookId, parentId, authorName || null, body, ipHash, ua]
    );

    return res.status(201).json({ ok: true, status: "pending", id });
  } catch (err) {
    console.error("POST /api/public/books/:id/comments error", err);
    return res.status(500).json({ error: "internal_error" });
  }
});

/**
 * GET /api/public/books/:id
 */
router.get("/:id", async (req, res) => {
  try {
    const pool = getPool(req);
    const id = String(req.params.id || "").trim();
    if (!id) return res.status(400).json({ error: "missing_id" });
    const lang = normalizeTitleLocale(req.query.lang);
    const ttReady = await titleTranslationsReady(pool);
    const buyReady = ttReady && (await titlePurchaseUrlReady(pool));

    const { rows } = await pool.query(
      `
      SELECT
        b.id::text AS id,
        b.author_id::text AS author_id,
        ${ttPurchaseUrlExpr(ttReady, buyReady)} AS purchase_url_locale,
        ${AUTHOR_EXPR} AS author_name_display,
        COALESCE(NULLIF(tt.title, ''), ${TITLE_EXPR}) AS book_title_display,
        ${TITLE_EXPR}  AS book_title_original,
        tt.title_kind,
        tt.edition_available,
        b.language AS edition_language,
        b.original_language,
        ${ttReady ? "b.original_title" : "NULL::text AS original_title"},
        b.publisher,
        b.pages,
        b.comment,
        b.purchase_source,
        b.purchase_url,
        b.isbn13,
        b.isbn10,
        b.reading_status,
        b.reading_status_updated_at,
        b.top_book,
        b.top_book_set_at,
        b.registered_at,
        bb.barcode,
        b.sub_genre_id,
  sg.name AS sub_genre_name,
  b.genre_id,
  g.abbr  AS genre_abbr
      FROM public.books b
      LEFT JOIN public.authors a ON a.id = b.author_id
      LEFT JOIN public.sub_genres sg ON sg.id = b.sub_genre_id
  LEFT JOIN public.genres g ON g.id = b.genre_id
      ${titleTranslationJoin(ttReady, "$2")}
      LEFT JOIN LATERAL (
        SELECT barcode
        FROM public.book_barcodes bb
        WHERE bb.book_id = b.id
        LIMIT 1
      ) bb ON true
      WHERE b.id::text = $1
      LIMIT 1
      `,
      [id, lang]
    );

    if (!rows[0]) return res.status(404).json({ error: "not_found" });

    const r = rows[0];

    let purchase = { best: null, candidates: [] };
    try {
      purchase = await buildPurchaseLinks(pool, {
        isbn13: r.isbn13,
        isbn10: r.isbn10,
        bookId: r.id,
      });
    } catch (e) {
      console.warn("purchase_providers not available or query failed:", e?.message || e);
    }

    // A purchase link for the edition in the UI language wins over the general one.
    const localeUrl = normStr(r.purchase_url_locale) || "";
    const manualUrl = localeUrl || normStr(r.purchase_url) || "";
    const bestUrl = normStr(purchase?.best?.url) || "";
    const finalUrl = manualUrl || bestUrl;

    const bestVendor =
      purchase?.best?.provider_name || purchase?.best?.provider_code || "";
    const finalVendor = manualUrl
      ? normStr(r.purchase_source) || "manual"
      : bestVendor;
    const coverUrl = resolveCoverUrl(r.id, lang);
    return res.json({
      id: r.id,
      cover_url: coverUrl,
      cover: coverUrl,

      authorId: r.author_id || null,

      authorNameDisplay: r.author_name_display || "",
      bookTitleDisplay: r.book_title_display || "",

      author: r.author_name_display || "",
      title: r.book_title_display || "",
      titleOriginal: r.book_title_original || "",
      title_original: r.book_title_original || "",
      titleLocale: lang,
      // 'original' | 'official' (published edition title) | 'free' (sinngemäß) | null (no row)
      titleKind: r.title_kind || null,
      originalTitle: r.original_title || null,
      // availability of a published edition in the requested UI language: true / false / null (unknown)
      editionAvailable: r.edition_available ?? null,
      editionLanguage: r.edition_language || null,
      originalLanguage: r.original_language || null,
      publisher: r.publisher,
      pages: r.pages,
      comment: r.comment,
sub_genre_id: r.sub_genre_id || null,
sub_genre_name: r.sub_genre_name || null,
genre_id: r.genre_id || null,
genre_abbr: r.genre_abbr || null,
      purchase_source: r.purchase_source || null,
      purchase_url: manualUrl || null,
      purchase_url_general: r.purchase_url || null,
      purchase_url_locale: localeUrl || null,
      purchase_url_best: bestUrl || null,
      purchase_vendor_best: bestVendor || null,
      purchase_url_final: finalUrl || null,
      purchase_vendor_final: finalVendor || null,
      purchase_links: (purchase?.candidates || []).map((c) => ({
        code: c.provider_code,
        name: c.provider_name,
        url: c.url,
        priority: c.priority,
      })),
      reading_status: r.reading_status,
      reading_status_updated_at: r.reading_status_updated_at,
      top_book: r.top_book,
      top_book_set_at: r.top_book_set_at,
      registered_at: r.registered_at,
      barcode: r.barcode,
    });
  } catch (err) {
    console.error("GET /api/public/books/:id error", err);
    return res.status(500).json({ error: "internal_error" });
  }
});

module.exports = router;
    