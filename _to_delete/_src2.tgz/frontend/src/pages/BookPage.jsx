import { useEffect, useMemo, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { useI18n } from "../context/I18nContext";
import { getPublicBook } from "../api/books";
import { createPublicBookComment, listPublicBookComments } from "../api/comments";
import { coverUrl } from "../utils/covers";
import { bookLangLabel, languageName } from "../utils/bookLanguages";
import "./BookPage.css";
import { useSeo } from "../utils/seo";

function isAbortError(e) {
  return (
    e?.name === "AbortError" ||
    String(e?.message || "").toLowerCase().includes("aborted")
  );
}

function getHost(url) {
  try {
    return new URL(url).host;
  } catch {
    return "";
  }
}

export default function BookPage() {
  const { id } = useParams();
  const [sp] = useSearchParams();
  const { t, locale } = useI18n();

  const safeId = useMemo(() => String(id || "").trim(), [id]);

  const coverFromQS = sp.get("cover") || "";
  const buyFromQS = sp.get("buy") || "";

  const [book, setBook] = useState(null);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(true);
  const [coverBroken, setCoverBroken] = useState(false);
  const [shareMsg, setShareMsg] = useState("");

  const [comments, setComments] = useState([]);
  const [commentsLoading, setCommentsLoading] = useState(false);
  const [commentsErr, setCommentsErr] = useState("");

  const [form, setForm] = useState({ authorName: "", body: "", website: "" });
  const [submitState, setSubmitState] = useState({
    busy: false,
    okMsg: "",
    errMsg: "",
  });

  const coverSrc = useMemo(() => {
    // Once loaded, the server's cover wins: it is the cover of the edition in the current UI language.
    const fromBook = book ? coverUrl(book) : "";
    if (fromBook) return fromBook;
    if (coverFromQS) return coverFromQS;
    return (safeId ? `/uploads/covers/normalized/${encodeURIComponent(safeId)}.jpg` : "");
  }, [coverFromQS, book, safeId]);

  useEffect(() => {
    const ac = new AbortController();

    (async () => {
      try {
        setLoading(true);
        setErr("");
        setBook(null);

        const data = await getPublicBook(safeId, { signal: ac.signal, lang: locale });
        setBook(data);
      } catch (e) {
        if (isAbortError(e)) return;
        setErr(e?.message || t("book.failed_to_load_book"));
      } finally {
        if (!ac.signal.aborted) setLoading(false);
      }
    })();

    return () => ac.abort();
  }, [safeId, t, locale]);

  useEffect(() => {
    if (!safeId) return;
    const ac = new AbortController();

    (async () => {
      try {
        setCommentsLoading(true);
        setCommentsErr("");
        const items = await listPublicBookComments(safeId, { signal: ac.signal });
        setComments(Array.isArray(items) ? items : []);
      } catch (e) {
        if (isAbortError(e)) return;
        setCommentsErr(e?.message || t("book.failed_to_load_comments"));
      } finally {
        if (!ac.signal.aborted) setCommentsLoading(false);
      }
    })();

    return () => ac.abort();
  }, [safeId, t]);

  async function submitComment(e) {
    e.preventDefault();
    setSubmitState({ busy: true, okMsg: "", errMsg: "" });

    try {
      const body = String(form.body || "").trim();
      const authorName = String(form.authorName || "").trim();

      if (body.length < 3) throw new Error(t("book.comment_too_short"));

      await createPublicBookComment(safeId, {
        authorName,
        body,
        website: form.website,
      });

      setForm({ authorName, body: "", website: "" });
      setSubmitState({
        busy: false,
        okMsg: t("book.comment_submit_success"),
        errMsg: "",
      });
    } catch (e2) {
      setSubmitState({
        busy: false,
        okMsg: "",
        errMsg: e2?.message || t("book.failed_to_submit_comment"),
      });
    }
  }

  const title = book?.title || "—";
  const author = book?.author || "—";
  const comment = book?.comment || "";

  const hasAuthor = author && author !== "—";
  useSeo({
    title: book
      ? hasAuthor
        ? t("seo.book.title", { title, author })
        : t("seo.book.title_noauthor", { title })
      : undefined,
    description: book
      ? comment
        ? `${hasAuthor ? `${title} – ${author}` : title}: ${comment}`
        : t("seo.book.desc", { title, author: hasAuthor ? author : "" })
      : undefined,
    path: safeId ? `/book/${encodeURIComponent(safeId)}` : undefined,
    image: book?.cover_url || undefined,
    type: "book",
    noindex: !!err,
  });

  // Link for the edition in the current UI language first (also after switching language on this page).
  const purchaseUrl = book?.purchase_url_locale || buyFromQS || book?.purchase_url || book?.purchase_link || "";
  const purchaseHost = purchaseUrl ? getHost(purchaseUrl) : "";

  async function shareBook() {
    const url = `${window.location.origin}/book/${encodeURIComponent(safeId)}`;
    const text = author && author !== "—" ? `${title} – ${author}` : title;

    if (navigator.share) {
      try {
        await navigator.share({ title, text, url });
        return;
      } catch (e) {
        if (e?.name === "AbortError") return; // user closed the share sheet
      }
    }

    try {
      await navigator.clipboard.writeText(url);
      setShareMsg(t("book.share_copied"));
    } catch {
      window.prompt(t("book.share_copy_prompt"), url);
    }
    window.setTimeout(() => setShareMsg(""), 2500);
  }

  const commentsApprovedText = commentsLoading
    ? t("book.loading")
    : `${comments.length} ${t("book.approved")}`;

  // Sub-genre link: needs sub_genre_id + sub_genre_name from API
  const subGenreId   = book?.sub_genre_id ?? null;
  const subGenreName = book?.sub_genre_name ?? book?.sub_genre ?? null;
  const genreAbbr    = book?.genre_abbr ?? book?.genre ?? null;

  return (
    <div className="zr-bookpage">
      <div className="zr-bookpage__top">
        <Link className="zr-btn2 zr-btn2--ghost" to="/">
          ← {t("book.back")}
        </Link>

        {purchaseUrl ? (
          <a
            className="zr-btn2 zr-btn2--primary"
            href={purchaseUrl}
            target="_blank"
            rel="noopener noreferrer"
            title={t("book.opens_in_new_tab")}
          >
            {t("book.purchase_link")} ↗
          </a>
        ) : (
          <span className="zr-bookpage__noLink">{t("book.no_purchase_link")}</span>
        )}
      </div>

      {loading ? (
        <div className="zr-bookpage__card">{t("book.loading")}</div>
      ) : err ? (
        <div className="zr-bookpage__card">
          <strong>{t("book.error")}</strong> {err}
        </div>
      ) : (
        <>
          <div className="zr-bookpage__grid">
            <div className="zr-bookpage__coverCard">
              {coverSrc && !coverBroken ? (
                <img
                  className="zr-bookpage__coverImg"
                  src={coverSrc}
                  alt={`${title} ${t("book.cover_suffix")}`}
                  onError={() => setCoverBroken(true)}
                />
              ) : (
                <div className="zr-bookpage__coverEmpty">
                  {t("book.no_cover_image")}
                  {safeId ? (
                    <div className="zr-bookpage__coverHint">
                      {t("book.expected")} <code>/uploads/covers/{safeId}.jpg</code>
                    </div>
                  ) : null}
                </div>
              )}
            </div>

            <div className="zr-bookpage__card">
              <h1 className="zr-bookpage__title">{title}</h1>
              {(() => {
                const orig = book?.originalTitle || book?.titleOriginal || "";
                return orig && orig !== title ? (
                  <div className="zr-bookpage__origTitle">
                    {bookLangLabel(locale, "original_title")}: {orig}
                  </div>
                ) : null;
              })()}
              <div className="zr-bookpage__author">{author || "—"}</div>
              {book?.editionLanguage || book?.originalLanguage || book?.titleKind ? (
                <div className="zr-bookpage__langs">
                  {book?.editionLanguage ? (
                    <span>{bookLangLabel(locale, "edition")}: {languageName(book.editionLanguage, locale)}</span>
                  ) : null}
                  {book?.originalLanguage && book.originalLanguage !== book.editionLanguage ? (
                    <span>{bookLangLabel(locale, "original")}: {languageName(book.originalLanguage, locale)}</span>
                  ) : null}
                  {book?.titleKind === "official" ? (
                    <span className="zr-bookpage__avail zr-bookpage__avail--yes">{bookLangLabel(locale, "kind_official")}</span>
                  ) : null}
                  {book?.titleKind === "free" ? (
                    <span className="zr-bookpage__avail">
                      {bookLangLabel(locale, book?.editionAvailable === false ? "kind_free_no" : "kind_free")}
                    </span>
                  ) : null}
                </div>
              ) : null}

              <div className="zr-bookpage__actions">
                {/* Ähnliche Bücher Button */}
                {subGenreId && subGenreName ? (
                  <Link
                    to={`/sub-genre/${book.sub_genre_id}?exclude=${book.id}`}
                    className="zr-btn2 zr-btn2--ghost zr-bookpage__similar-btn"
                  >
                    Ähnliche Bücher · {book.sub_genre_name} →
                  </Link>
                ) : null}

                <button
                  type="button"
                  className="zr-btn2 zr-btn2--ghost zr-bookpage__share-btn"
                  onClick={shareBook}
                  title={t("book.share_title")}
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <circle cx="18" cy="5" r="3" />
                    <circle cx="6" cy="12" r="3" />
                    <circle cx="18" cy="19" r="3" />
                    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" />
                    <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" />
                  </svg>
                  {t("book.share")}
                </button>

                {shareMsg ? (
                  <span className="zr-bookpage__shareMsg" role="status">{shareMsg}</span>
                ) : null}
              </div>

              <div className="zr-bookpage__leaveBox">
                <div className="zr-bookpage__leaveHeader">
                  <h3 className="zr-bookpage__leaveTitle">{t("book.leave_comment")}</h3>
                  <div className="zr-bookpage__commentsMeta">{commentsApprovedText}</div>
                </div>

                <div className="zr-bookpage__hint">{t("book.comment_hint")}</div>

                {submitState.okMsg ? (
                  <div className="zr-bookpage__noticeOk">{submitState.okMsg}</div>
                ) : null}
                {submitState.errMsg ? (
                  <div className="zr-bookpage__noticeErr">{submitState.errMsg}</div>
                ) : null}

                <form className="zr-bookpage__form" onSubmit={submitComment}>
                  <label className="zr-bookpage__label">
                    {t("book.name_optional")}
                    <input
                      className="zr-input"
                      value={form.authorName}
                      onChange={(e) =>
                        setForm((p) => ({ ...p, authorName: e.target.value }))
                      }
                      maxLength={80}
                      placeholder={t("book.guest")}
                    />
                  </label>

                  <input
                    tabIndex={-1}
                    autoComplete="off"
                    className="zr-bookpage__hp"
                    value={form.website}
                    onChange={(e) => setForm((p) => ({ ...p, website: e.target.value }))}
                    name="website"
                  />

                  <label className="zr-bookpage__label">
                    {t("book.comment_label")}
                    <textarea
                      className="zr-input"
                      value={form.body}
                      onChange={(e) => setForm((p) => ({ ...p, body: e.target.value }))}
                      rows={6}
                      maxLength={2000}
                      placeholder={t("book.comment_placeholder")}
                      required
                    />
                  </label>

                  <button
                    className="zr-btn2 zr-btn2--primary"
                    type="submit"
                    disabled={submitState.busy}
                  >
                    {submitState.busy ? t("book.sending") : t("book.submit")}
                  </button>
                </form>
              </div>

              {comment ? (
                <div className="zr-bookpage__commentBox">
                  <div className="zr-bookpage__commentTitle">{t("book.my_comment")}</div>
                  <div
                    className="zr-bookpage__commentText"
                    style={{ whiteSpace: "pre-wrap" }}
                  >
                    {comment}
                  </div>
                </div>
              ) : null}

              <div className="zr-bookpage__buyBox">
                <div className="zr-bookpage__buyTitle">{t("book.purchase")}</div>

                {purchaseUrl ? (
                  <>
                    <div className="zr-bookpage__buyText">{t("book.stay_on_site")}</div>

                    <a
                      className="zr-bookpage__buyLink"
                      href={purchaseUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      {t("book.open_purchase_link")} {purchaseHost ? `(${purchaseHost})` : ""} ↗
                    </a>
                  </>
                ) : (
                  <div className="zr-bookpage__buyText">{t("book.no_purchase_link_yet")}</div>
                )}
              </div>
            </div>
          </div>

          <div className="zr-bookpage__card">
            <div className="zr-bookpage__commentsHeader">
              <h2 className="zr-bookpage__commentsTitle">{t("book.comments")}</h2>
              <div className="zr-bookpage__commentsMeta">{commentsApprovedText}</div>
            </div>

            {commentsErr ? (
              <div className="zr-bookpage__commentsError">{commentsErr}</div>
            ) : null}

            <div className="zr-bookpage__commentsList">
              {commentsLoading ? (
                <div className="zr-bookpage__commentsEmpty">{t("book.loading")}</div>
              ) : comments.length ? (
                comments.map((c) => (
                  <div key={c.id} className="zr-bookpage__comment">
                    <div className="zr-bookpage__commentTop">
                      <div className="zr-bookpage__commentAuthor">
                        {c.author_name || t("book.guest")}
                      </div>
                      <div className="zr-bookpage__commentDate">
                        {c.created_at
                          ? new Date(c.created_at).toLocaleDateString(locale || undefined)
                          : ""}
                      </div>
                    </div>
                    <div className="zr-bookpage__commentBody" style={{ whiteSpace: "pre-wrap" }}>
                      {c.body}
                    </div>
                  </div>
                ))
              ) : (
                <div className="zr-bookpage__commentsEmpty">{t("book.no_comments_yet")}</div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
