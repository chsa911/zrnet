import { Link } from "react-router-dom";
import { ADMIN_HOTKEYS, useAdminHotkeys } from "./AdminHotkeys";
import { useEffect, useMemo, useRef, useState } from "react";
import "./topbar.css";
import { useI18n } from "../context/I18nContext";
import { API_BASE } from "../api/config";

// Language "identity" colors (used as font + dot color in the dropdown,
// and as font color on the green button for non-EN).
// NOTE: Pure yellow text is hard to read on light backgrounds, so ES uses a darker gold.
const LANGS = [
  { locale: "en", label: "EN", accent: "#00C27A" }, // green (default)
  { locale: "de", label: "DE", accent: "#dc2626" }, // red
  { locale: "es", label: "ES", accent: "#B8860B" }, // golden yellow (legible)
  { locale: "fr", label: "FR", accent: "#2563eb" }, // blue
  { locale: "pt-BR", label: "PT-BR", accent: "#111111" }, // black
];

const BUTTON_BG = "#00C27A"; // keep button background always green (like the Start button)

function normalizeLocale(input) {
  const l = String(input || "").trim();
  if (!l) return "en";
  if (l.toLowerCase().startsWith("pt")) return "pt-BR";
  return l.includes("-") ? l.split("-")[0] : l;
}

function metaForLocale(locale) {
  const n = normalizeLocale(locale);
  return LANGS.find((x) => x.locale.toLowerCase() === n.toLowerCase()) || LANGS[0];
}

export default function TopBar() {
  const moreRef = useRef(null);
  const langRef = useRef(null);
  const { locale, setLocale, t } = useI18n();

  const activeLang = useMemo(() => metaForLocale(locale), [locale]);
  const [isAdmin, setIsAdmin] = useState(false);
  useAdminHotkeys(isAdmin);

  useEffect(() => {
    let active = true;

    fetch(`${API_BASE || "/api"}/admin/me`, { credentials: "include" })
      .then((res) => {
        if (active) setIsAdmin(res.ok);
      })
      .catch(() => {
        if (active) setIsAdmin(false);
      });

    return () => {
      active = false;
    };
  }, []);


  // Button font rule:
  // - EN => black on green
  // - otherwise => language accent color (PT-BR accent is already black)
  const buttonTextColor = useMemo(() => {
    const n = normalizeLocale(locale).toLowerCase();
    if (n === "en") return "#111111";
    return activeLang.accent;
  }, [locale, activeLang.accent]);

  useEffect(() => {
    const onPointerDown = (e) => {
      const more = moreRef.current;
      if (more?.open && !more.contains(e.target)) more.open = false;

      const lang = langRef.current;
      if (lang?.open && !lang.contains(e.target)) lang.open = false;
    };

    const onKeyDown = (e) => {
      if (e.key !== "Escape") return;
      const more = moreRef.current;
      if (more?.open) more.open = false;
      const lang = langRef.current;
      if (lang?.open) lang.open = false;
    };

    window.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("keydown", onKeyDown);

    return () => {
      window.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("keydown", onKeyDown);
    };
  }, []);

  const closeMore = () => {
    if (moreRef.current?.open) moreRef.current.open = false;
  };

  const closeLang = () => {
    if (langRef.current?.open) langRef.current.open = false;
  };

  const onPickLocale = (l) => {
    setLocale(l);
    closeLang();
  };

  return (
    <header className="zr-topbar">
      <div className="zr-topbar__inner">
        <Link to="/" className="zr-brand" aria-label="Christophers Pages Home">
          Christophers Pages
        </Link>

        <nav className="zr-nav" aria-label="Main navigation">
          <Link className="zr-nav__link" to="/info/how-it-works">
            {t("nav_technique")}
          </Link>
          <Link className="zr-nav__link" to="/news">
            {t("nav_news")}
          </Link>
          <Link className="zr-nav__link" to="/author-stats">
            {t("nav_authors")}
          </Link>
          <Link className="zr-nav__link" to="/reading-diary">
            {t("nav_readingdiary")}
          </Link>
          <Link className="zr-nav__link" to="/info/faq">
            {t("nav_faq")}
          </Link>
          <a
            className="zr-nav__link"
            href="mailto:christopher@christopherspages.com?subject=Christophers%20Pages%20Kontakt"
          >
            {t("nav_contact")}
          </a>

          <details ref={moreRef} className="zr-more">
            <summary className="zr-nav__link">{t("nav_more")}</summary>

            <div className="zr-more__menu" role="menu"
              onClick={(e) => {
                if (e.target.closest?.("a")) closeMore();
              }}
              >
{isAdmin ? (<>
<Link to="/admin/register">Register <span className="zr-more__key">{ADMIN_HOTKEYS["/admin/register"]}</span></Link>
<Link to="/admin/search-update">Search / Update <span className="zr-more__key">{ADMIN_HOTKEYS["/admin/search-update"]}</span></Link>
<Link to="/admin/authors">Authors <span className="zr-more__key">{ADMIN_HOTKEYS["/admin/authors"]}</span></Link>
<Link to="/admin/abbreviations">Abbreviations <span className="zr-more__key">{ADMIN_HOTKEYS["/admin/abbreviations"]}</span></Link>
<Link to="/admin/highlights/received">Highlights</Link>
<Link to="/admin/sync-issues">Sync Issues <span className="zr-more__key">{ADMIN_HOTKEYS["/admin/sync-issues"]}</span></Link>
<Link to="/admin/barcodes">Barcodes <span className="zr-more__key">{ADMIN_HOTKEYS["/admin/barcodes"]}</span></Link>
<Link to="/admin/check-book">Buch prüfen <span className="zr-more__key">{ADMIN_HOTKEYS["/admin/check-book"]}</span></Link>
<Link to="/admin/barcode-check">Prüfen &amp; Ergänzen <span className="zr-more__key">{ADMIN_HOTKEYS["/admin/barcode-check"]}</span></Link>
<Link to="/admin/covers">Cover <span className="zr-more__key">{ADMIN_HOTKEYS["/admin/covers"]}</span></Link>
<hr/>
</>) : null}
<Link to="/recent-highlights">Recent Highlights</Link>
              <Link to="/info/impressum">{t("nav_impressum")}</Link>
              <Link to="/info/datenschutz">{t("nav_privacy")}</Link>
            </div>
          </details>

          <details ref={langRef} className="zr-langmenu">
            <summary
              className="zr-btn zr-langbtn"
              aria-label={t("lang_label")}
              style={{
                background: BUTTON_BG,
                color: buttonTextColor,
                borderColor: "rgba(0,0,0,0.12)",
              }}
            >
              <span
                className="zr-langdot"
                aria-hidden="true"
                style={{ background: buttonTextColor }}
              />
              {activeLang.label}
            </summary>

            <div className="zr-langmenu__menu" role="menu">
              {LANGS.map((l) => {
                const isActive = l.locale.toLowerCase() === activeLang.locale.toLowerCase();

                return (
                  <button
                    key={l.locale}
                    type="button"
                    role="menuitem"
                    className={`zr-langmenu__item${isActive ? " is-active" : ""}`}
                    onClick={() => (isActive ? closeLang() : onPickLocale(l.locale))}
                    aria-current={isActive ? "true" : undefined}
                  >
                    <span
                      className="zr-langdot"
                      aria-hidden="true"
                      style={{ background: l.accent }}
                    />
                    <span className="zr-langlabel" style={{ color: l.accent }}>
                      {l.label}
                    </span>
                    {isActive ? (
                      <span className="zr-langcheck" aria-hidden="true">
                        ✓
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </div>
          </details>
        </nav>
      </div>
    </header>
  );
}
