import { Link } from "react-router-dom";
import { useI18n } from "../context/I18nContext";
 
const SOCIALS = [
  { key: "nav_youtube", href: "https://www.youtube.com/@pagesinline" },
  { key: "nav_tiktok", href: "https://www.tiktok.com/@christopherspages" },
];

export default function Footer() {
  const { t } = useI18n();
  const year = new Date().getFullYear();

  return (
    <footer className="zr-footer">
      <div className="zr-footer__inner">
        <div className="zr-footer__left">
          <div className="zr-footer__copy">© {year} Christophers Pages</div>
          <div className="zr-footer__disclaimer">
            <strong>{t("footer_disclaimer_label")}</strong> {t("footer_disclaimer_text")}
          </div>
        </div>

        <div className="zr-footer__right">
          <nav className="zr-footer__links" aria-label={t("footer_links_label")}>
             <a href="mailto:christopher@christopherspages.com?subject=Christophers%20Pages%20Kontakt">{t("nav_contact")}</a>
         {/*   <Link to="/newsletter">{t("nav_newsletter")}</Link>*/}
            <Link to="/info/faq">{t("nav_faq")}</Link>
            <Link to="/info/datenschutz">{t("nav_privacy")}</Link>
            <Link to="/info/impressum">{t("nav_impressum")}</Link>
          </nav>

          <nav className="zr-footer__social" aria-label={t("footer_social_label")}>
            {SOCIALS.map((s) => (
              <a key={s.key} href={s.href} target="_blank" rel="noreferrer noopener">
                {t(s.key)}
              </a>
            ))}
          </nav>
        </div>
      </div>
    </footer>
  );
}
