import React, { Suspense, lazy, useEffect, useState } from "react";
import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import Layout from "./components/Layout";
import ActivitiesToday from "./components/ActivitiesToday";
import "./styles/css/zr-admin.css";
import Home from "./pages/Home";
import ComingSoonPage from "./pages/ComingSoonPage";
import CollectionPage from "./pages/CollectionPage";
import { findComingSoon } from "./utils/comingSoon";
import LegacyHtmlPage from "./pages/LegacyHtmlPage";
import InfoPage from "./pages/InfoPage";
import BookThemesPage from "./pages/BookThemesPage";
import ThemeBooksPage from "./pages/ThemeBooksPage";
import StatsDetailPage from "./pages/StatsDetailPage";
import MostReadAuthorsPage from "./pages/MostReadAuthorsPage";
import AuthorReadingStatsPage from "./pages/AuthorReadingStatsPage";
import AuthorsOverviewPage from "./pages/AuthorsOverviewPage";
import AuthorPage from "./pages/AuthorPage";
import BookPage from "./pages/BookPage";
/*import NewsletterPage from "./pages/NewsletterPage";
*/
import ThemeSubthemesAuthorsPage from "./pages/ThemeSubthemesAuthorsPage";
import { processUploadQueue } from "./utils/uploadQueue";
import AuthorsIndexPage from "./pages/AuthorsIndexPage";
import NewsPage from "./pages/NewsPage";
import HomeTitlesPage from "./pages/HomeTitlesPage";
import { API_BASE } from "./api/config";
import SubGenrePage from "./pages/SubGenrePage";
import CoachingPage from "./pages/CoachingPage";
import ReadingDiaryPage from "./pages/ReadingDiaryPage";

// Admin-only pages are loaded on demand so visitors don't download them.
const AnalyticsPage = lazy(() => import("./pages/AnalyticsPage"));
const AdminCommentsPage = lazy(() => import("./pages/AdminCommentsPage"));
const AdminPage = lazy(() => import("./pages/AdminPage"));
const AdminAuthorsOverviewPage = lazy(() => import("./pages/AdminAuthorsOverviewPage"));
const RegisterPage = lazy(() => import("./pages/RegisterPage"));
const SearchUpdatePage = lazy(() => import("./pages/SearchUpdatePage"));
const SyncIssuePage = lazy(() => import("./pages/SyncIssuePage"));
const BarcodeDashboardPage = lazy(() => import("./pages/BarcodeDashboardPage"));
const AbbreviationsAdminPage = lazy(() => import("./pages/AbbreviationsAdminPage"));
const AdminAuthorTitlesPage = lazy(() => import("./pages/AdminAuthorTitlesPage"));
const AdminAuthorPage = lazy(() => import("./pages/AdminAuthorPage"));
const HighlightReceivedPage = lazy(() => import("./pages/HighlightReceivedPage"));
const AdminTitleTranslationsPage = lazy(() => import("./pages/AdminTitleTranslationsPage"));
const AdminCoversPage = lazy(() => import("./pages/AdminCoversPage"));
const KauflinkUpdatePage = lazy(() => import("./pages/KauflinkUpdatePage"));
const AdminPhysCodeCheckPage = lazy(() => import("./pages/AdminPhysCodeCheckPage"));
const AdminBarcodeCheckPage = lazy(() => import("./pages/AdminBarcodeCheckPage"));
const ENV_BASE = (import.meta?.env?.VITE_API_BASE_URL || import.meta?.env?.VITE_API_BASE || "").trim();
const BASE = String(ENV_BASE || API_BASE || "/api").replace(/\/$/, "");

function buildApiUrl(path) {
  if (/^https?:\/\//i.test(path)) return path;
  const p = path.startsWith("/") ? path : `/${path}`;
  if (BASE.endsWith("/api") && p.startsWith("/api/")) return `${BASE}${p.slice(4)}`;
  return `${BASE}${p}`;
}

function RequireAdmin({ children }) {
  const location = useLocation();
  const [state, setState] = useState("checking");

  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const res = await fetch(buildApiUrl("/admin/me"), { credentials: "include" });
        if (!cancelled) setState(res.ok ? "ok" : "denied");
      } catch {
        if (!cancelled) setState("denied");
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [location.pathname]);

  if (state === "checking") {
    return <div className="zr-card">Checking login…</div>;
  }

  if (state !== "ok") {
    const next = `${location.pathname}${location.search || ""}`;
    return <Navigate to={`/admin?next=${encodeURIComponent(next)}`} replace />;
  }

  return children;
}

// Alle Admin-Seiten: Dashboard "Activities today" + einheitliche Schrift (zr-admin.css).
// plain = eigene große Schrift behalten (Register, Search & Update).
function AdminOnly({ children, plain = false }) {
  return (
    <RequireAdmin>
      <div className={plain ? undefined : "zr-admin"}>
        <ActivitiesToday />
        {children}
      </div>
    </RequireAdmin>
  );
}

// Unknown path: show "coming soon" for pages listed in utils/comingSoon.js,
// otherwise a friendly 404 in the site's design.
function NotFound() {
  const { pathname } = useLocation();
  const soon = findComingSoon(pathname);
  if (soon) return <ComingSoonPage eta={soon.eta} titleKey={soon.title || ""} />;
  return <ComingSoonPage notFound />;
}

export default function App() {
  // Safety net: retry any locally queued registrations/uploads when the app opens or comes online.
  useEffect(() => {
    let alive = true;

    const run = async () => {
      try {
        await processUploadQueue({ maxJobs: 10 });
      } catch {
        // ignore (queue persists)
      }
    };

    run();

    const onOnline = () => alive && run();
    const onVis = () => {
      if (!alive) return;
      if (document.visibilityState === "visible") run();
    };

    window.addEventListener("online", onOnline);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      alive = false;
      window.removeEventListener("online", onOnline);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, []);

  return (
    <Suspense fallback={null}>
    <Routes>
      {/* ✅ Make the layout route explicit */}
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        {/* Social-media entry points: show the home page, but keep the
            path so Cloudflare Web Analytics can tell the channels apart.
            Linked as christopherspages.com/youtube and /tiktok, which
            Cloudflare redirects here. */}
        <Route path="youtube" element={<Home />} />
        <Route path="tiktok" element={<Home />} />
        <Route path="titles" element={<HomeTitlesPage />} />
        <Route path="collection" element={<CollectionPage />} />

        {/* book themes */}
        <Route path="bookthemes" element={<BookThemesPage />} />
        <Route path="bookthemes/:abbr" element={<ThemeBooksPage />} />
        <Route path="bookthemes.html" element={<Navigate to="/bookthemes" replace />} />

        <Route path="news" element={<NewsPage />} />
        <Route path="beta-test" element={<Navigate to="/news" replace />} />
        <Route path="coaching" element={<CoachingPage />} />

        {/* analytics */}
        <Route path="analytics/*" element={<AnalyticsPage />} />

        {/* removed public merch/equipment pages for the DHDL-facing site */}
        <Route path="merch" element={<Navigate to="/" replace />} />
        <Route path="checkout" element={<Navigate to="/" replace />} />
        <Route path="order/:orderId" element={<Navigate to="/" replace />} />
        <Route path="merchandise.html" element={<Navigate to="/" replace />} />

        {/* newsletter */}
{    /*    <Route path="newsletter" element={<NewsletterPage />} />
        <Route path="newsletter.html" element={<Navigate to="/newsletter" replace />} />
*/}
        {/* static info pages (React + i18n) */}
        <Route path="info/:slug" element={<InfoPage />} />
        <Route path="info/so-funktionierts" element={<Navigate to="/info/how-it-works" replace />} />
        <Route path="info/beschaffung" element={<Navigate to="/info/sourcing" replace />} />

        {/* legacy static routes → info/:slug */}
        <Route path="technik.html" element={<Navigate to="/info/how-it-works" replace />} />
        <Route path="info/technik" element={<Navigate to="/info/how-it-works" replace />} />
        <Route path="info/ausruestung" element={<Navigate to="/info/how-it-works" replace />} />
        <Route path="ausruestung.html" element={<Navigate to="/info/how-it-works" replace />} />
        <Route path="beschaffung.html" element={<Navigate to="/info/sourcing" replace />} />
        <Route path="faq.html" element={<Navigate to="/info/faq" replace />} />
        <Route path="haeufige_fragen.html" element={<Navigate to="/info/faq" replace />} />
        <Route path="haeufige_fragen_d.html" element={<Navigate to="/info/faq" replace />} />
        <Route path="recent-highlights" element={<Navigate to="/titles" replace />} />
        <Route path="impressum.html" element={<Navigate to="/info/impressum" replace />} />
        <Route path="impressum_d.html" element={<Navigate to="/info/impressum" replace />} />
        <Route path="datenschutz.html" element={<Navigate to="/info/datenschutz" replace />} />
        <Route path="admin/authors/:authorId" element={<AdminOnly><AdminAuthorPage /></AdminOnly>} />
        <Route path="admin/authors/:authorId/titles" element={<AdminOnly><AdminAuthorTitlesPage /></AdminOnly>} />
        {/* book detail */}
        <Route path="book/:id" element={<BookPage />} />
        <Route path="sub-genre/:id" element={<SubGenrePage />} />
        {/* author detail */}
        <Route path="author/:author" element={<AuthorPage />} />
        {/* alphabetical authors overview (public) */}
        
        <Route path="authors" element={<AuthorsOverviewPage />} />
        <Route path="bookthemes/:abbr/subthemes" element={<ThemeSubthemesAuthorsPage />} />
        {/* admin */}
        <Route path="admin/abbreviations" element={<AdminOnly><AbbreviationsAdminPage /></AdminOnly>} />
        <Route path="admin" element={<AdminPage />} />
        <Route path="admin/register" element={<AdminOnly plain><RegisterPage createReadingStatus="in_progress" /></AdminOnly>} />
        <Route path="admin/authors" element={<AdminOnly><AdminAuthorsOverviewPage /></AdminOnly>} />
        <Route path="admin/search-update" element={<AdminOnly plain><SearchUpdatePage /></AdminOnly>} />
        <Route path="admin/check-book" element={<AdminOnly><AdminPhysCodeCheckPage /></AdminOnly>} />
        <Route path="admin/barcode-check" element={<AdminOnly><AdminBarcodeCheckPage /></AdminOnly>} />
        <Route path="admin/sync-issues" element={<AdminOnly><SyncIssuePage /></AdminOnly>} />
        <Route path="admin/barcodes" element={<AdminOnly><BarcodeDashboardPage /></AdminOnly>} />
        <Route path="admin/comments" element={<AdminOnly><AdminCommentsPage /></AdminOnly>} />
        <Route path="login" element={<Navigate to="/admin" replace />} />
        <Route path="login.html" element={<Navigate to="/admin" replace />} />
<Route
  path="admin/books/:bookId/kauflink"
  element={
    <AdminOnly>
      <KauflinkUpdatePage />
    </AdminOnly>
  }
/>
<Route
  path="admin/highlights/received"
  element={
    <AdminOnly>
      <HighlightReceivedPage />
    </AdminOnly>
  }
/>
<Route path="admin/title-translations" element={<AdminOnly><AdminTitleTranslationsPage /></AdminOnly>} />
<Route path="admin/covers" element={<AdminOnly><AdminCoversPage /></AdminOnly>} />
        {/* legacy admin links */}
        <Route path="register" element={<Navigate to="/admin/register" replace />} />
        <Route path="update" element={<Navigate to="/admin/search-update" replace />} />
        <Route path="admin.html" element={<Navigate to="/admin" replace />} />

        {/* stats */}
        <Route path="stats/:type" element={<StatsDetailPage />} />

        {/* Top authors */}
        <Route path="top-authors" element={<MostReadAuthorsPage />} />
        <Route path="author-stats" element={<AuthorReadingStatsPage />} />
        {/* Lesetagebuch */}
        <Route path="reading-diary" element={<ReadingDiaryPage />} />
        <Route path="lesetagebuch" element={<Navigate to="/reading-diary" replace />} />
        <Route path="autoren_meistgelesen.html" element={<Navigate to="/top-authors" replace />} />
        <Route path="autoren_meist_gelesen.html" element={<Navigate to="/top-authors" replace />} />

        {/* other legacy html routes (fallback) */}
        <Route path=":page.html" element={<LegacyHtmlPage />} />

        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
    </Suspense>
  );
}
