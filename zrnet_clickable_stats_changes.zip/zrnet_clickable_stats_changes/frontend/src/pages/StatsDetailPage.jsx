import React, { useEffect, useMemo, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { useI18n } from "../context/I18nContext";
import "./StatsDetailPage.css";

const TYPE_CONFIG = {
  stock: {
    bucket: "registered",
    labelKey: "stats_in_stock",
    dateField: "registered_at",
    dateLabel: "Registered",
  },
  finished: {
    bucket: "finished",
    labelKey: "stats_finished",
    dateField: "reading_status_updated_at",
    dateLabel: "Finished",
  },
  abandoned: {
    bucket: "abandoned",
    labelKey: "stats_abandoned",
    dateField: "reading_status_updated_at",
    dateLabel: "Abandoned",
  },
  top: {
    bucket: "top",
    labelKey: "stats_top",
    dateField: "top_book_set_at",
    dateLabel: "Top",
  },
};

function fmtDate(v) {
  if (!v) return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString();
}

export default function StatsDetailPage() {
  const { t } = useI18n();
  const { type } = useParams();
  const [sp] = useSearchParams();

  const cfg = TYPE_CONFIG[type] || null;
  const yearParsed = Number(sp.get("year"));
  const year = Number.isFinite(yearParsed) ? yearParsed : new Date().getFullYear();

  const [limit, setLimit] = useState(50);
  const [offset, setOffset] = useState(0);
  const [qInput, setQInput] = useState("");
  const [q, setQ] = useState("");

  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // debounce search input
  useEffect(() => {
    const handle = setTimeout(() => {
      setOffset(0);
      setItems([]);
      setQ(qInput.trim());
    }, 300);
    return () => clearTimeout(handle);
  }, [qInput]);

  // reset paging when switching type/year/limit
  useEffect(() => {
    setOffset(0);
    setItems([]);
  }, [type, year, limit]);

  const title = useMemo(() => {
    if (!cfg) return "Stats";
    return `${t(cfg.labelKey)} — ${year}`;
  }, [cfg, t, year]);

  useEffect(() => {
    if (!cfg) return;

    const ac = new AbortController();

    (async () => {
      setLoading(true);
      setError("");
      try {
        const params = new URLSearchParams();
        params.set("bucket", cfg.bucket);
        if (Number.isFinite(year)) params.set("year", String(year));
        if (q) params.set("q", q);
        params.set("limit", String(limit));
        params.set("offset", String(offset));
        params.set("meta", "1");

        const r = await fetch(`/api/public/books?${params.toString()}`, {
          headers: { Accept: "application/json" },
          signal: ac.signal,
        });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const data = await r.json();

        const nextItems = Array.isArray(data?.items) ? data.items : Array.isArray(data) ? data : [];
        const nextTotal = Number(data?.total ?? nextItems.length);

        setTotal(Number.isFinite(nextTotal) ? nextTotal : nextItems.length);
        setItems((prev) => (offset === 0 ? nextItems : [...prev, ...nextItems]));
      } catch (e) {
        if (!ac.signal.aborted) {
          setError(e?.message || String(e));
          setTotal(0);
          setItems([]);
        }
      } finally {
        if (!ac.signal.aborted) setLoading(false);
      }
    })();

    return () => ac.abort();
  }, [cfg, year, q, limit, offset]);

  if (!cfg) {
    return (
      <div className="zr-stats-detail">
        <h1 className="zr-stats-detail-title">404</h1>
        <p>Unknown stats type.</p>
        <Link to="/" className="zr-stats-detail-back">← Back</Link>
      </div>
    );
  }

  const canLoadMore = items.length < total;

  return (
    <div className="zr-stats-detail">
      <div className="zr-stats-detail-head">
        <div>
          <h1 className="zr-stats-detail-title">{title}</h1>
          <div className="zr-stats-detail-sub">
            {loading ? "Loading…" : `${items.length}${total ? ` / ${total}` : ""}`}
            {q ? ` • “${q}”` : ""}
          </div>
        </div>
        <Link to="/" className="zr-stats-detail-back">← {t("nav_home")}</Link>
      </div>

      <div className="zr-stats-detail-controls">
        <input
          className="zr-input"
          value={qInput}
          onChange={(e) => setQInput(e.target.value)}
          placeholder={t("search_placeholder")}
          aria-label={t("search_placeholder")}
        />

        <select
          className="zr-select"
          value={limit}
          onChange={(e) => setLimit(Number(e.target.value) || 50)}
          aria-label="Rows per page"
        >
          <option value={25}>25</option>
          <option value={50}>50</option>
          <option value={100}>100</option>
          <option value={200}>200</option>
        </select>
      </div>

      {error ? <div className="zr-stats-detail-error">Error: {error}</div> : null}

      <div className="zr-table-wrap">
        <table className="zr-table">
          <thead>
            <tr>
              <th>Title</th>
              <th>Author</th>
              <th>{cfg.dateLabel}</th>
              <th>Barcode</th>
            </tr>
          </thead>
          <tbody>
            {!loading && items.length === 0 ? (
              <tr>
                <td colSpan={4} className="zr-empty">No results.</td>
              </tr>
            ) : (
              items.map((b) => (
                <tr key={b.id}>
                  <td className="zr-strong">{b.title || "—"}</td>
                  <td>{b.author || "—"}</td>
                  <td>{fmtDate(b[cfg.dateField])}</td>
                  <td className="zr-mono">{b.barcode || "—"}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="zr-stats-detail-footer">
        <button
          className="zr-btn"
          disabled={loading || !canLoadMore}
          onClick={() => setOffset((o) => o + limit)}
        >
          {canLoadMore ? "Load more" : "All loaded"}
        </button>
      </div>
    </div>
  );
}
